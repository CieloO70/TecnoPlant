/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.basecode.tecnoplant.model;

/**
 *
 * @author Asus
 */
public class Planta {
    int idPlanta; 			
    String nombre; 				
    String habitat; 			
    String tipo; 				
    String descripcion; 		
    String cultivo; 			
    String cuidado; 
    int estatus; 			
    String fechaRegistro; 		
    String foto;
    Usuario usuario;

    public Planta(){
        
    }
    
    public Planta(int idPlanta, String nombre, String habitat, String tipo, String descripcion, String cultivo, String cuidado, int estatus, String fechaRegistro, String foto, Usuario usuario) {
        this.idPlanta = idPlanta;
        this.nombre = nombre;
        this.habitat = habitat;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.cultivo = cultivo;
        this.cuidado = cuidado;
        this.estatus = estatus;
        this.fechaRegistro = fechaRegistro;
        this.foto = foto;
        this.usuario = usuario;
    }

    public int getIdPlanta() {
        return idPlanta;
    }

    public void setIdPlanta(int idPlanta) {
        this.idPlanta = idPlanta;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCultivo() {
        return cultivo;
    }

    public void setCultivo(String cultivo) {
        this.cultivo = cultivo;
    }

    public String getCuidado() {
        return cuidado;
    }

    public void setCuidado(String cuidado) {
        this.cuidado = cuidado;
    }

    public int getEstatus() {
        return estatus;
    }

    public void setEstatus(int estatus) {
        this.estatus = estatus;
    }

    public String getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(String fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    
    
}
