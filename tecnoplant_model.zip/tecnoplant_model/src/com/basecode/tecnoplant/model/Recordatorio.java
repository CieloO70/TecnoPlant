/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.basecode.tecnoplant.model;

/**
 *
 * @author Asus
 */
public class Recordatorio {
    int idRecordatorio;
    String frecuenciaRiego;
    String frecuenciaPoda;
    String frecuenciaFertilizacion;
    String descripcion;
    String fechaHoraAgregado;
    String horaNotificacion;
    String repeticionNotificacion;
    int estatus;
    Planta planta;
    Usuario usuario;
    
    public Recordatorio(){
        
    }

    public Recordatorio(int idRecordatorio, String frecuenciaRiego, String frecuenciaPoda, String frecuenciaFertilizacion, String descripcion, String fechaHoraAgregado, String horaNotificacion, String repeticionNotificacion, int estatus, Planta planta, Usuario usuario) {
        this.idRecordatorio = idRecordatorio;
        this.frecuenciaRiego = frecuenciaRiego;
        this.frecuenciaPoda = frecuenciaPoda;
        this.frecuenciaFertilizacion = frecuenciaFertilizacion;
        this.descripcion = descripcion;
        this.fechaHoraAgregado = fechaHoraAgregado;
        this.horaNotificacion = horaNotificacion;
        this.repeticionNotificacion = repeticionNotificacion;
        this.estatus = estatus;
        this.planta = planta;
        this.usuario = usuario;
    }

    
    
    public int getIdRecordatorio() {
        return idRecordatorio;
    }

    public void setIdRecordatorio(int idRecordatorio) {
        this.idRecordatorio = idRecordatorio;
    }

    public String getFrecuenciaRiego() {
        return frecuenciaRiego;
    }

    public void setFrecuenciaRiego(String frecuenciaRiego) {
        this.frecuenciaRiego = frecuenciaRiego;
    }

    public String getFrecuenciaPoda() {
        return frecuenciaPoda;
    }

    public void setFrecuenciaPoda(String frecuenciaPoda) {
        this.frecuenciaPoda = frecuenciaPoda;
    }

    public String getFrecuenciaFertilizacion() {
        return frecuenciaFertilizacion;
    }

    public void setFrecuenciaFertilizacion(String frecuenciaFertilizacion) {
        this.frecuenciaFertilizacion = frecuenciaFertilizacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getFechaHoraAgregado() {
        return fechaHoraAgregado;
    }

    public void setFechaHoraAgregado(String fechaHoraAgregado) {
        this.fechaHoraAgregado = fechaHoraAgregado;
    }

    public String getHoraNotificacion() {
        return horaNotificacion;
    }

    public void setHoraNotificacion(String horaNotificacion) {
        this.horaNotificacion = horaNotificacion;
    }

    public String getRepeticionNotificacion() {
        return repeticionNotificacion;
    }

    public void setRepeticionNotificacion(String repeticionNotificacion) {
        this.repeticionNotificacion = repeticionNotificacion;
    }

    public int getEstatus() {
        return estatus;
    }

    public void setEstatus(int estatus) {
        this.estatus = estatus;
    }

    public Planta getPlanta() {
        return planta;
    }

    public void setPlanta(Planta planta) {
        this.planta = planta;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    
}
