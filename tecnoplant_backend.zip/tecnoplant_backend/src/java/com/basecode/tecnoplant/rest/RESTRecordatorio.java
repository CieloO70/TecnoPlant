/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.basecode.tecnoplant.rest;
import com.basecode.tecnoplant.core.ControllerRecordatorio;
import com.basecode.tecnoplant.model.Recordatorio;
import com.google.gson.Gson;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 *
 * @author Asus
 */
@Path("recordatorio")
public class RESTRecordatorio {
    @Path("save")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Response save(@FormParam("datosRecordatorio") @DefaultValue("") String datosRecordatorio){
        ControllerRecordatorio cr = new ControllerRecordatorio();
        Gson gson = new Gson();
        String receivedData = "";
        Recordatorio r = gson.fromJson(datosRecordatorio, Recordatorio.class);
        receivedData = gson.toJson(r);
        try{
            int id = cr.insert(r);
            String out = "{\"result\":\"Datos del recordatorio guardados correctamente.\", \"receivedData\": " + receivedData + ", \"ID Generado\": " + id + "}";
            return Response.ok(out).build();
        }catch(Exception ex){
            String error = String.format("{\"exception\":\"Ocurrio un error en el servidor. %s\", \"receivedData\": %s}",
                    ex.toString().replaceAll("\"", ""), receivedData);
            return Response.ok(error).build();
        }
    }
    
    @Path("cancel")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response cancel(@QueryParam("idRecordatorio") @DefaultValue("0") int idRecordatorio) {
        ControllerRecordatorio cr = new ControllerRecordatorio();
        String out = null;

        try {
            int id = cr.cancel(idRecordatorio);
            out = "{\"result\":\"Eliminar recordatorio.\", \"Estatus\": " + id + "}";

            
        } catch (Exception ex) {
            out = """
                  {"exception":"Ocurrio un error en el servidor. El recordatorio no fue eliminado correctamente. %s"}
                  """;
            out = String.format(out, ex.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
    
    @Path("getAll")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll() {
        ControllerRecordatorio cr = new ControllerRecordatorio();
        List<Recordatorio> recordatorios = null;
        String out = null;
        Gson gson = new Gson();
        try {
            recordatorios = cr.getAll();
            out = gson.toJson(recordatorios);
        } catch (Exception e) {
            e.printStackTrace();
            out = "{\"exception\":" + e.toString().replaceAll("\"", "") + "\"}";
        }

        return Response.ok(out).build();
    }
}
