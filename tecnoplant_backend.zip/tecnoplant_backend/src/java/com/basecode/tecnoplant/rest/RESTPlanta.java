/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.basecode.tecnoplant.rest;
import com.basecode.tecnoplant.core.ControllerPlanta;
import com.basecode.tecnoplant.model.Planta;
import com.google.gson.Gson;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 *
 * @author Asus
 */
@Path("planta")
public class RESTPlanta {
    @Path("save")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Response save(@FormParam("planta") String planta){
        System.out.println(planta);
        Gson gson = new Gson();
        Planta p = gson.fromJson(planta, Planta.class);
        String out = "";
        try{
            ControllerPlanta cp = new ControllerPlanta();
            cp.insertP(p);
            out = """
                  {"idPlanta":"1"}
                  """;
        }catch(Exception e){
            System.out.println(e.getMessage());
            out = """
                  {"idPlanta":"0"}
                  """;
        }
        return Response.ok(out).build();
    }
    
    @Path("getAll")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll(@QueryParam("activas") boolean activas) {
        ControllerPlanta ce = new ControllerPlanta();
        List<Planta> plantas = null;
        String out = null;
        Gson gson = new Gson();
        try {
            plantas = ce.getAll(activas);
            out = gson.toJson(plantas);
        } catch (Exception e) {
            e.printStackTrace();
            out = "{\"exception\":" + e.toString().replaceAll("\"", "") + "\"}";
        }
        return Response.ok(out).build();
    }

    @Path("delete")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response delete(@QueryParam("idPlanta") @DefaultValue("0") int idPlanta) {
        ControllerPlanta p = new ControllerPlanta();
        String out = null;
        try {
            p.delete(idPlanta);
            out = """
              {"result":"Planta eliminada lógicamente de manera exitosa."}
              """;
        } catch (Exception ex) {
            ex.printStackTrace();
            out = """
              {"exception":"Ocurrió un error en el servidor. La Planta no se ha eliminado correctamente. %s"}
              """;
            out = String.format(out, ex.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }

}
