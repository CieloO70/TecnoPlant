/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.basecode.tecnoplant.core;

import com.basecode.tecnoplant.db.ConexionMySQL;
import com.basecode.tecnoplant.model.Planta;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author Asus
 */
public class ControllerPlanta {

    public Planta insertP(Planta p) throws Exception {
        String query = "INSERT INTO planta"
                + "(idPlanta, nombre, habitat, tipo, descripcion, cultivo,cuidado,foto, idUsuario, fechaRegistro, estatus)"
                + "VALUES (?,?,?,?,?,?,?,?,?,NOW(),'1');";
        try {
            ConexionMySQL connMySQL = new ConexionMySQL();
            Connection conn = connMySQL.open();

            PreparedStatement pstm = conn.prepareStatement(query);
            pstm.setInt(1, p.getIdPlanta());
            pstm.setString(2, p.getNombre());
            pstm.setString(3, p.getHabitat());
            pstm.setString(4, p.getTipo());
            pstm.setString(5, p.getDescripcion());
            pstm.setString(6, p.getCultivo());
            pstm.setString(7, p.getCuidado());
            pstm.setString(8, p.getFoto());
            pstm.setInt(9, p.getUsuario().getIdUsuario());
            pstm.execute();
            return p;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return p;
        }
    }

    public void delete(int idPlanta) throws Exception {
        //Instruccion
        String sql = "UPDATE planta SET estatus = 0 WHERE idPlanta=?";
        //Coneccion con MySQL
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        //Prepared Statemen
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, idPlanta);
        pstmt.executeUpdate();
        conn.close();
    }

    public List<Planta> getAll(boolean activas) throws Exception {
        String sql = "SELECT * FROM v_plantas";
        if (activas) {
            sql += " WHERE estatus = 1";
        }
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        ArrayList<Planta> plantas = new ArrayList<>();

        while (rs.next()) {
            Planta p = fill(rs);
            plantas.add(p);
        }
        rs.close();
        pstmt.close();
        conn.close();

        return plantas;
    }

    private Planta fill(ResultSet rs) throws Exception {
        Planta p = new Planta();

        // Venta
        p.setIdPlanta(rs.getInt("idPlanta"));
        p.setNombre(rs.getString("nombre"));
        p.setHabitat(rs.getString("habitat"));
        p.setTipo(rs.getString("tipo"));
        p.setDescripcion(rs.getString("descripcion"));
        p.setCultivo(rs.getString("cultivo"));
        p.setCuidado(rs.getString("cuidado"));
        p.setEstatus(rs.getInt("Estatus"));
        p.setFechaRegistro(rs.getString("fechaRegistro"));

        return p;
    }

}
