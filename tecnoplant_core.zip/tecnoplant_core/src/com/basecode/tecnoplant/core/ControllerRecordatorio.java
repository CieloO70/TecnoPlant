/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.basecode.tecnoplant.core;

import com.basecode.tecnoplant.db.ConexionMySQL;
import com.basecode.tecnoplant.model.Planta;
import com.basecode.tecnoplant.model.Recordatorio;
import com.basecode.tecnoplant.model.Usuario;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author Asus
 */
public class ControllerRecordatorio {
    
    //Agregar un recordatorio
    //Recibimos los datos necesarios para generar un recordatorio y obtenemos el id de este.
    public int insert(Recordatorio r) throws Exception{
        //Definir la consulta SQL que se ejecutara
        String sql = "CALL generarRecordatorio(?,?,?,?,?,?,?,?,?)";
        
        //Abrir la conexion con BD
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        
        //Inicio de la transacción
        conn.setAutoCommit(false);
        
        //Realizar la accion en la base de datos
        try{
            CallableStatement cstmt = conn.prepareCall(sql);
            
            //Llenar el CallableStatement
            cstmt.setString(1, r.getFrecuenciaRiego());
            cstmt.setString(2, r.getFrecuenciaPoda());
            cstmt.setString(3, r.getFrecuenciaFertilizacion());
            cstmt.setString(4,r.getDescripcion());
            cstmt.setString(5, r.getHoraNotificacion());
            cstmt.setString(6, r.getRepeticionNotificacion());
            cstmt.setInt(7, r.getPlanta().getIdPlanta());
            cstmt.setInt(8, r.getUsuario().getIdUsuario());
            
            //Definir parametro de retorno
            cstmt.registerOutParameter(9, Types.INTEGER);
            
            //Ejecutar el procedure
            cstmt.executeUpdate();
            
            conn.commit();
            
            //Recuperar el id del recordatorio
            int idRecordatorio = 0;
            idRecordatorio = cstmt.getInt(9);
            r.setIdRecordatorio(idRecordatorio);
            
            //Cerrar la conexión
            cstmt.close();
            conn.close();
            
            return idRecordatorio;
        }catch(Exception e){
            conn.rollback();
            return 0;
        }
    }
    
    
    //Eliminar de manera logica un recordatorio
    //De realizar la eliminación correctamente obtenemos un 1, de caso contrario un 0.
    public int cancel(int id) throws Exception{
        //Instrucción SQL
        String sql = """
                     UPDATE recordatorio SET estatus = 0 WHERE idRecordatorio = ?
                     """;
        
        //Conexion con MySQL
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();

        //Inicio de la transacción
        conn.setAutoCommit(false);
        
        try{
            //Prepared Statement 
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setInt(1, id);

            int cambio = pstmt.executeUpdate();

            if (cambio == 0) {
                conn.rollback();
                return -1;
            }

            conn.commit();

            //Cerrar conexion
            pstmt.close();
            conn.close();

            //Confirmar
            return 1;
        }catch (Exception e) {
            conn.rollback();
            return 0;
        }
    }
    
    //Obtener todos los recordatorios activos
    public List<Recordatorio> getAll() throws Exception{
        String sql = "SELECT * FROM v_recordatorios WHERE estatus = 1";
        
        //Abrir conexion con MySQL
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        
        //ArrayList
        ArrayList<Recordatorio> recordatorios = new ArrayList();
        
        while(rs.next()){
            Recordatorio r = fill(rs);
            recordatorios.add(r);
        }
        
        rs.close();
        pstmt.close();
        conn.close();
        return recordatorios;
    }

    private Recordatorio fill(ResultSet rs) throws SQLException {
        Recordatorio r = new Recordatorio();
        Planta p = new Planta();
        Usuario u = new Usuario();
        
        //Datos del recordatorio
        r.setIdRecordatorio(rs.getInt("idRecordatorio"));
        r.setFrecuenciaRiego(rs.getString("frecuenciaRiego"));
        r.setFrecuenciaPoda(rs.getString("frecuenciaPoda"));
        r.setFrecuenciaFertilizacion(rs.getString("frecuenciaFertilizacion"));
        r.setDescripcion(rs.getString("descripcion"));
        r.setHoraNotificacion(rs.getString("horaNotificacion"));
        r.setRepeticionNotificacion(rs.getString("repeticionNotificacion"));
        r.setEstatus(rs.getInt("estatus"));
        
        //Datos de la planta
        p.setIdPlanta(rs.getInt("idPlanta"));
        p.setNombre(rs.getString("nombre"));
        p.setFoto(rs.getString("foto"));
        r.setPlanta(p);
        
        //Datos del usuario
        u.setIdUsuario(rs.getInt("idUsuario"));
        u.setNombre(rs.getString("nombreUsuario"));
        u.setApellidoPaterno(rs.getString("apellidoPaterno"));
        u.setApellidoMaterno(rs.getString("apellidoMaterno"));
        r.setUsuario(u);
        
        return r;
        
    }
}
